﻿using System;
using Debug_et_tests;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace TestEtDebugTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestClassique()
        {
            var result = ClasseChaine.RetourneInitiales("Loïc DESROSIERS");
            Assert.IsTrue(result == "L.D.");
        }
        [TestMethod]
        public void TestDeuxPrenoms()
        {
            var result = ClasseChaine.RetourneInitiales("Jean Michel DESROSIERS");
            Assert.IsTrue(result == "J.M.D.");
        }
        [TestMethod]
        public void TestChaineVide()
        {
            var result = ClasseChaine.RetourneInitiales("");
            Assert.IsTrue(result == "");
        }
        [TestMethod]
        public void TestPrenomCompose()
        {
            var result = ClasseChaine.RetourneInitiales("Jean-Michel DESROSIERS");
            Assert.IsTrue(result == "J.M.D.");
        }
    }
}
