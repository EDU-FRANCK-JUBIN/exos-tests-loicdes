﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Debug_et_tests
{
    public class ClasseChaine
    {
        public static String RetourneInitiales(string chaine)
        {
            string toReturn = "";
            if (chaine.Length > 0)
            {
                string[] prenoms = chaine.Split(' ');
                foreach (string prenom in prenoms)
                {
                    foreach (string composite in prenom.Split('-'))
                    {
                        toReturn += composite[0] + ".";
                    }
                }
            }
            return toReturn;
        }
    }
}
